//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ActiveView.rc
//
#define IDR_MAINFRAME                   2
#define IDR_ACTIVEVIEWTYPE              3
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_PRINTDIALOG                 101
#define IDC_EDIT1                       1001
#define IDC_RADIO1                      1002
#define IDC_RADIO2                      1003
#define IDC_CHECK1                      1004
#define IDC_CHECK2                      1005
#define IDC_EDIT2                       1006
#define ID_VIEW_PREVPAGE                32771
#define ID_VIEW_NEXTPAGE                32772
#define ID_VIEW_FIRSTPAGE               32773
#define ID_VIEW_LASTPAGE                32774
#define ID_VIEW_ACTUALSIZE              32775
#define ID_VIEW_FITPAGE                 32776
#define ID_VIEW_FITWIDTH                32777
#define ID_TOOLS_HAND                   32778
#define ID_TOOLS_HILITEWORDS            32779
#define ID_EDIT_SELECTALL               32780
#define ID_EDIT_SELECTTEXT              32781
#define ID_EDIT_SELECTGRAPHIC           32782
#define ID_TOOLS_HILITEBYRECT           32783
#define ID_TOOLS_ACQUIREBOOKMARK        32784
#define ID_TOOLS_ACQUIREANNOT           32785
#define ID_TOOLS_ADDLINKANNOT           32786
#define ID_TOOLS_ADDTEXTANNOT           32787
#define ID_TOOLS_DISPLAYAPERTURE        32788

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
