// This has been renamed
#include "IADMFixed.hpp"
