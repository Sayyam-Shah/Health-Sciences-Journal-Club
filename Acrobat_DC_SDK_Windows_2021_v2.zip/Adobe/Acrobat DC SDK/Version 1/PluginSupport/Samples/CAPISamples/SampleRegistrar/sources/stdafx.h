// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <stdio.h>
#include <tchar.h>

// Windows Header Files
#include <windows.h>
#include <WinCrypt.h>
#include <WinInet.h>
#include <Rpc.h>

#include <tchar.h>
#include <assert.h>
#include <iostream>
#include <strstream>
#include <sstream>
#include <fcntl.h>
#include <share.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <io.h>
#include <stdio.h>

#include <vector>
#include <list>
#include <algorithm>

#include "sampleCommon.h"
#include "sampleTypes.h"
#include "sampleHandles.h"

