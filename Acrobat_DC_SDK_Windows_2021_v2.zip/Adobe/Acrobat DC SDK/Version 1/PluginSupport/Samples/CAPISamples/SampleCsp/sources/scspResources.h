//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by scspResources.rc
//
#define IDD_PIN_DIALOG                  102
#define IDI_PIN_ICON                    106
#define IDC_PIN                         1001
#define IDC_PIN_PROMPT                  1002
#define IDC_ICON1                       1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
